 CREATE TABLE course
 (
  course_id int , 
  course_name varchar(30),
  course_duration int NOT NULL,
  COURSE_FEE FLOAT NOT NULL
  CONSTRAINT course_pk PRIMARY KEY(course_id)
   );
   INSERT INTO course (course_id,course_name,course_duration,COURSE_FEE)VALUES(3,'b.tech',4,35.06);
 CREATE TABLE student1
(
 student_id int NOT NULL,
 course_id int,
 student_name varchar(30),
 student_course varchar(30),
 student_marks float NOT NULL,
 student_age int NOT NULL,
 student_address varchar(50),
 CONSTRAINT student_pk PRIMARY KEY(student_id),
 CONSTRAINT fk_course
 FOREIGN KEY (course_id)
 REFERENCES course(course_id)
 );
 INSERT INTO student1(student_id,course_id,student_name,student_course,student_marks,student_age,student_address)VALUES(123,3,'harish','cse',33.06,21,'hno123');
 SELECT*FROM student1;