package com;

public class go {

	public static void main(String[] args) 
	{
	int num1;
	for(num1=1;num1<=10;num1++);
	System.out.println(num1);
	int x=1;
	if(x>0 || x++<10)
	{
		System.out.println("Hello:"+x);
		
	}
	else
	{
		System.out.println("Hai:"+x);
	}
	}

}
