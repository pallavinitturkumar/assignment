package com;

public class ExceptionDemo {

	public static void main(String[] args) {
		int num1=10,num2=0,result;
		try
		{
			result=num1/num2;
			System.out.println("result:"+result);
		}
		catch(ArithmeticException ae)
		{
			System.out.println("Exception Ocurred:"+ae);
		}
		finally
		{
			System.out.println("Finally Block");
		}

	}

}
