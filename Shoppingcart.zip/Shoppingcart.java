package com;
import java.util.*;
public class Shoppingcart {

	public static void main(String[] args) 
	{
		ArrayList<Product> cart=new ArrayList<Product>();
        Product p1=new Product("p101","tv",6000,3);
        Product p2=new Product("p102","mp3",3000,3);
        Product p3=new Product("p103","table",1500,3);
        cart.add(p1);
        cart.add(p2);
        cart.add(p3);
        for(Product p:cart)
        {
        	System.out.println("product id:"+p.getpid());
        	System.out.println("product name:"+p.getname());
        	System.out.println("price:"+p.getprice());
        	System.out.println("no products:"+p.getnoof());
        }
	}

}
